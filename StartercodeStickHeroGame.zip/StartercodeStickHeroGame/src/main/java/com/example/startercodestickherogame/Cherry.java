package com.example.startercodestickherogame;

// Cherry class
public class Cherry extends Collidable {
    private int value;

    public void gather() {

    }

    @Override
    public void checkAndHandle() {

    }


}