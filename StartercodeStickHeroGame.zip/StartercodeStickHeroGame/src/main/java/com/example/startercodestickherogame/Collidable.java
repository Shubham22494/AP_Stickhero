package com.example.startercodestickherogame;

public abstract class Collidable {
    public abstract void checkAndHandle();
}
