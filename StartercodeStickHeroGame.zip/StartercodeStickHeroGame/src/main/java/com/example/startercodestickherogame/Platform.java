package com.example.startercodestickherogame;

public class Platform {
    private double width;


    public double getWidth() {
        return width;
    }

    public void generate() {

    }
}

