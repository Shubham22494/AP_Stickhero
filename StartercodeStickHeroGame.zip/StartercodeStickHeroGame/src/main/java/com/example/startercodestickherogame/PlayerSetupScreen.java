package com.example.startercodestickherogame;

public class PlayerSetupScreen {
    private StickHeroGame stickHeroGame;//dependency

    public PlayerSetupScreen(StickHeroGame stickHeroGame) {
        this.stickHeroGame = stickHeroGame;

    }

    public void displaySetupScreen() {

    }

    public void submitPlayerName(String name) {

    }

    public void closeSetupScreen() {

    }
}
