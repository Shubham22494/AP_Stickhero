package com.example.startercodestickherogame;

public interface Revivable {
    boolean isRevivable();
    void revive();
}
