package com.example.startercodestickherogame;
public class Reward {
    private int rewardPoints;

    public int getRewardPoints() {

        return rewardPoints;
    }
}


