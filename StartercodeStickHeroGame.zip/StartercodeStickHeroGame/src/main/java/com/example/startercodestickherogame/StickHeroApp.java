package com.example.startercodestickherogame;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
//import javafx.scene.media.AudioClip;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

public class StickHeroApp extends Application {

    private static final String BACKGROUND_MUSIC = "";
    private  StartScreen sc;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Stick Hero");
        Button startButton = new Button("Start Game");
        startButton.setOnAction(event->StartingGame());
        Scene startScene;
        startScene=new Scene(startButton,300,200);
        primaryStage.setScene(startScene);
        //For BONUS _USING THREADS
        Thread musicThread = new Thread(() -> playBackgroundMusic());
        musicThread.start();
        primaryStage.show();



    }

    private void playBackgroundMusic() {
        MediaPlayer music=new MediaPlayer(new Media(new File(BACKGROUND_MUSIC).toURI().tostring());

        music.setCycleCount(music.INDEFINITE);
        music.play();

    }

    private void StartingGame(){
        StickHeroGame stickherogame=new StickHeroGame();
        Scene gamescene=new Scene(sc ,800,600);
        primaryStage.setScene(gameScene);




    }

//    private void playGameAnimation() {
//
//
//    }

}
