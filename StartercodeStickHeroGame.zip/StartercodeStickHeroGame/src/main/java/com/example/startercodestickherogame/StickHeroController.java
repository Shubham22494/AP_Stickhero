package com.example.startercodestickherogame;
import javafx.fxml.FXML;
import javafx.scene.control.Label;


public class StickHeroController {
    private StickHeroGame stickHeroGame;  // Composition

    public StickHeroController() {
        this.stickHeroGame = stickHeroGame;
    }



    public void processInput() {
    }
}