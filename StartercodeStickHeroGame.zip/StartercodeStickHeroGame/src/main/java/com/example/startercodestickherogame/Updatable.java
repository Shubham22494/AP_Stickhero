package com.example.startercodestickherogame;

public interface Updatable {
    void updateGame();
}
